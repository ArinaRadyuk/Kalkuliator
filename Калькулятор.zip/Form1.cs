﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulator
{
    public partial class Form1 : Form

    {
        bool isokPervash = true;
        bool isokVtorash = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private Tuple<double,bool> check(object sender)
        {
            double x;
            try
            {
                x = Double.Parse((sender as TextBox).Text);
            }
            catch
            {
                return Tuple.Create(0.0 , false);
            }
            return Tuple.Create(x,true);
        }
        private void mojBatonPlus_Click(object sender, EventArgs e)
        {
            if (!isokPervash || !isokVtorash) { SanyaCool.Text = "Error!"; }
            else
            {
                SanyaCool.Text = (Double.Parse(MojPervash.Text) + Double.Parse(mojVtorash.Text)).ToString();
            }
           
        }

        private void MojBatonMinus_Click(object sender, EventArgs e)
        {
            if (!isokPervash || !isokVtorash) { SanyaCool.Text = "Error!"; }
            else
            {
                SanyaCool.Text = (Double.Parse(MojPervash.Text) - Double.Parse(mojVtorash.Text)).ToString();
            }
        }

        private void MojBatonDivide_Click(object sender, EventArgs e)
        {
            if (!isokPervash || !isokVtorash) { SanyaCool.Text = "Error!"; }
            else
            {
                SanyaCool.Text = (Double.Parse(MojPervash.Text) / Double.Parse(mojVtorash.Text)).ToString();
            }
        }
        private void MojBatonUmnozhit_Click(object sender, EventArgs e)
        {
            if(!isokPervash||!isokVtorash) { SanyaCool.Text = "Error!"; }
            else
            {
                SanyaCool.Text = (Double.Parse(MojPervash.Text) * Double.Parse(mojVtorash.Text)).ToString();
            }         
        }

        private void mojVtorash_Enter(object sender, EventArgs e)
        {
        }

        private void MojPervash_Validating(object sender, CancelEventArgs e)
        {
            Tuple <double,bool> info = check(MojPervash);
            if (info.Item2 == false)
            {
                MessageBox.Show("Invalid first number");
                isokPervash = false;
            }
            else
            {
                isokPervash = true;
            }
        }

        private void mojVtorash_Validating(object sender, CancelEventArgs e)
        {
            Tuple<double, bool> info = check(mojVtorash);
            if (info.Item2 == false)
            {
                MessageBox.Show("Invalid second number");
                isokVtorash = false;
            }
            else { isokVtorash = true; }
        }
    }
}
