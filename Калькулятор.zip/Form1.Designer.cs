﻿namespace Kalkulator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mojBatonPlus = new System.Windows.Forms.Button();
            this.MojbatonUmnozhit = new System.Windows.Forms.Button();
            this.MojBatonDivide = new System.Windows.Forms.Button();
            this.MojBatonMinus = new System.Windows.Forms.Button();
            this.mojVtorash = new System.Windows.Forms.TextBox();
            this.MojPervash = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.SanyaCool = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            this.SuspendLayout();
            // 
            // mojBatonPlus
            // 
            this.mojBatonPlus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.mojBatonPlus.Location = new System.Drawing.Point(247, 135);
            this.mojBatonPlus.Name = "mojBatonPlus";
            this.mojBatonPlus.Size = new System.Drawing.Size(112, 34);
            this.mojBatonPlus.TabIndex = 0;
            this.mojBatonPlus.Text = "+";
            this.mojBatonPlus.UseVisualStyleBackColor = false;
            this.mojBatonPlus.Click += new System.EventHandler(this.mojBatonPlus_Click);
            // 
            // MojbatonUmnozhit
            // 
            this.MojbatonUmnozhit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MojbatonUmnozhit.Location = new System.Drawing.Point(247, 256);
            this.MojbatonUmnozhit.Name = "MojbatonUmnozhit";
            this.MojbatonUmnozhit.Size = new System.Drawing.Size(112, 34);
            this.MojbatonUmnozhit.TabIndex = 0;
            this.MojbatonUmnozhit.Text = "*";
            this.MojbatonUmnozhit.UseVisualStyleBackColor = false;
            this.MojbatonUmnozhit.Click += new System.EventHandler(this.MojBatonUmnozhit_Click);
            // 
            // MojBatonDivide
            // 
            this.MojBatonDivide.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MojBatonDivide.Location = new System.Drawing.Point(247, 216);
            this.MojBatonDivide.Name = "MojBatonDivide";
            this.MojBatonDivide.Size = new System.Drawing.Size(112, 34);
            this.MojBatonDivide.TabIndex = 0;
            this.MojBatonDivide.Text = "/";
            this.MojBatonDivide.UseVisualStyleBackColor = false;
            this.MojBatonDivide.Click += new System.EventHandler(this.MojBatonDivide_Click);
            // 
            // MojBatonMinus
            // 
            this.MojBatonMinus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MojBatonMinus.Location = new System.Drawing.Point(247, 176);
            this.MojBatonMinus.Name = "MojBatonMinus";
            this.MojBatonMinus.Size = new System.Drawing.Size(112, 34);
            this.MojBatonMinus.TabIndex = 0;
            this.MojBatonMinus.Text = "-";
            this.MojBatonMinus.UseVisualStyleBackColor = false;
            this.MojBatonMinus.Click += new System.EventHandler(this.MojBatonMinus_Click);
            // 
            // mojVtorash
            // 
            this.mojVtorash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(120)))), ((int)(((byte)(170)))));
            this.mojVtorash.Location = new System.Drawing.Point(375, 86);
            this.mojVtorash.Name = "mojVtorash";
            this.mojVtorash.Size = new System.Drawing.Size(150, 31);
            this.mojVtorash.TabIndex = 1;
            this.mojVtorash.Text = "0";
            this.mojVtorash.Enter += new System.EventHandler(this.mojVtorash_Enter);
            this.mojVtorash.Validating += new System.ComponentModel.CancelEventHandler(this.mojVtorash_Validating);
            // 
            // MojPervash
            // 
            this.MojPervash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(120)))), ((int)(((byte)(170)))));
            this.MojPervash.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MojPervash.Location = new System.Drawing.Point(95, 86);
            this.MojPervash.Name = "MojPervash";
            this.MojPervash.Size = new System.Drawing.Size(150, 24);
            this.MojPervash.TabIndex = 2;
            this.MojPervash.Text = "0";
            this.MojPervash.Validating += new System.ComponentModel.CancelEventHandler(this.MojPervash_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(113, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "First number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(387, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Second number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(268, 368);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Result";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // SanyaCool
            // 
            this.SanyaCool.BackColor = System.Drawing.Color.Aquamarine;
            this.SanyaCool.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SanyaCool.Location = new System.Drawing.Point(199, 309);
            this.SanyaCool.Name = "SanyaCool";
            this.SanyaCool.Size = new System.Drawing.Size(200, 25);
            this.SanyaCool.TabIndex = 7;
            this.SanyaCool.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(658, 444);
            this.Controls.Add(this.SanyaCool);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MojPervash);
            this.Controls.Add(this.mojVtorash);
            this.Controls.Add(this.MojBatonMinus);
            this.Controls.Add(this.MojBatonDivide);
            this.Controls.Add(this.MojbatonUmnozhit);
            this.Controls.Add(this.mojBatonPlus);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mojBatonPlus;
        private System.Windows.Forms.Button MojbatonUmnozhit;
        private System.Windows.Forms.Button MojBatonDivide;
        private System.Windows.Forms.Button MojBatonMinus;
        private System.Windows.Forms.TextBox mojVtorash;
        private System.Windows.Forms.TextBox MojPervash;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.Label SanyaCool;
    }
}

